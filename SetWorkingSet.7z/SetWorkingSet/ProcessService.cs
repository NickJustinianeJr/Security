using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;


namespace SetWorkingSet
{
    public static class ProcessService
    {
		const int PROCESS_WM_READ = 0x0010;
		const int PROCESS_VM_WRITE = 0x0020;
		const int PROCESS_VM_OPERATION = 0x0008;
		const int PROCESS_SET_QUOTA = 0x0100;
		const int PROCESS_ALL_ACCESS = 0x1F0FFF;
		
		
		[DllImport("kernel32.dll")]
		public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);
		
		//[DllImport("kernel32.dll")]
		//public static extern bool SetProcessWorkingSetSize(IntPtr processHandle, long dwMinimumWorkingSetSize, long dwMaximumWorkingSetSize);
		
		[DllImport("kernel32.dll")]
		public static extern bool SetProcessWorkingSetSize(IntPtr hProcess, UIntPtr dwMinimumWorkingSetSize, UIntPtr dwMaximumWorkingSetSize);
		
		//[DllImport("KERNEL32.DLL", EntryPoint = "SetProcessWorkingSetSize", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
		//internal static extern bool SetProcessWorkingSetSize32(IntPtr pProcess, int dwMinimumWorkingSetSize, int dwMaximumWorkingSetSize);


		//[DllImport("KERNEL32.DLL", EntryPoint = "SetProcessWorkingSetSize", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
		//internal static extern bool SetProcessWorkingSetSize64(IntPtr pProcess, long dwMinimumWorkingSetSize, long dwMaximumWorkingSetSize);
		
		
		public static void SetProcessWorkingSet(string processName)
		{
			Process[] processes = Process.GetProcessesByName(processName);
			
			foreach (Process process in processes)
			{
				try
				{
					IntPtr processHandle = OpenProcess(PROCESS_SET_QUOTA, false, process.Id);
					
					long minimumWorkingSet = 1600000000;
					long maximumWorkingSet = 1821000000;
					
					UIntPtr ptr1 = (UIntPtr)minimumWorkingSet;
					UIntPtr ptr2 = (UIntPtr)maximumWorkingSet;
					
					//long minimumWorkingSet = 61DEEE80L;
					//long maximumWorkingSet = 61DEEE80L;
					
					Console.WriteLine("Process ID: " + process.Id);
					
					bool result = SetProcessWorkingSetSize(processHandle, ptr1, ptr2);
										
					Console.WriteLine("Result: " + result);
										
						if (result)
						{
							Console.WriteLine("Process has been set");
						}
						else
						{
							Console.WriteLine("Failed to set the working set");
						}
					
					
					Console.WriteLine();
					
				}					
				catch (Exception ex)
				{
					Console.WriteLine("Message: " + ex.Message);
					Console.WriteLine("Stack Trace: " + ex.StackTrace);
				}
				
			}			
			
		}
		
		
	}
}