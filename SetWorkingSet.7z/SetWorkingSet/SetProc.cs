using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;


namespace SetWorkingSet
{
	public class SetProc
	{
		public static void Main(string[] args)
		{
			string processName = args[0];
			
			Console.WriteLine("Process Name: " + processName);
			Console.WriteLine();		
			
			ProcessService.SetProcessWorkingSet(processName);	
		}
	
	}

}