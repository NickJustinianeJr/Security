﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace LowLevelDesign.DebuggerHelpbelt
{
    static class PkgCmdIDList
    {

        public const uint cmdidDebuggerHelpBelt =    0x101;

    };
}