﻿using System;

namespace Musketeer.Models
{
    public class Service
    {
        public String Name { get; set; }
        public String DisplayName { get; set; }
    }
}
