﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Threading;
using Dapper;
using Musketeer.Models;
using MySql.Data.MySqlClient;
using Topshelf.Logging;

namespace Musketeer
{
    sealed class ServiceMonitor
    {
        public const int SleepIntervalInMilliSecs = 50000;

        private readonly LogWriter logger = HostLogger.Get<ServiceMonitor>();
        private IList<Tuple<int, PerformanceCounter>> serviceCounters;

        public void Monitor(object state)
        {
            ManualResetEvent stopHandle = (ManualResetEvent)state;
            String machineName = Environment.MachineName;
            try
            {
                Initialize();
                var snapshots = new ServiceCounterSnapshot[serviceCounters.Count];

                while (!MusketeerWorker.ShouldStop)
                {
                    Thread.Sleep(SleepIntervalInMilliSecs);

                    // this would be our timestamp value by which we will group the snapshots
                    DateTime timeStamp = DateTime.UtcNow;
                    // collect snapshots
                    for (int i = 0; i < serviceCounters.Count; i++)
                    {
                        var snapshot = new ServiceCounterSnapshot();
                        snapshot.CreationTimeUtc = timeStamp;
                        snapshot.SnapshotMachineName = machineName;
                        snapshot.ServiceCounterId = serviceCounters[i].Item1;
                        try
                        {
                            snapshot.ServiceCounterValue = serviceCounters[i].Item2.NextValue();
                            logger.DebugFormat("Performance counter {0} read value: {1}", GetPerfCounterPath(serviceCounters[i].Item2),
                                                snapshot.ServiceCounterValue);
                        }
                        catch (InvalidOperationException)
                        {
                            snapshot.ServiceCounterValue = null;
                            logger.DebugFormat("Performance counter {0} didn't send any value.", GetPerfCounterPath(serviceCounters[i].Item2));
                        }
                        snapshots[i] = snapshot;
                    }
                    SaveServiceSnapshots(snapshots);
                }
            }
            finally
            {
                stopHandle.Set();
            }
        }

        private void Initialize()
        {
            var counters = new List<Tuple<int, PerformanceCounter>>();
            using (var conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySqlDiagnosticsDb"].ConnectionString))
            {
                conn.Open();
                foreach (var counter in conn.Query<ServiceCounter>("select Id,ServiceName,CategoryName,CounterName,InstanceName from service_counters"))
                {
                    logger.InfoFormat(@"Creating performance counter: {0}\{1}\{2}\{3}", counter.MachineName ?? ".", counter.CategoryName, 
                                        counter.CounterName, counter.InstanceName);
                    var perfCounter = new PerformanceCounter(counter.CategoryName, counter.CounterName, counter.InstanceName, counter.MachineName ?? ".");
                    counters.Add(new Tuple<int, PerformanceCounter>(counter.Id, perfCounter));
                    // first value doesn't matter so we should call the counter at least once
                    try { perfCounter.NextValue(); } catch { }
                }
            }
            serviceCounters = counters;
        }

        private void SaveServiceSnapshots(IEnumerable<ServiceCounterSnapshot> snapshots)
        {
            using (var conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySqlDiagnosticsDb"].ConnectionString))
            {
                conn.Open();
                foreach (var snapshot in snapshots)
                {
                    // insert new snapshot to the database
                    conn.Execute(
    @"insert into service_counter_snapshots(ServiceCounterId,SnapshotMachineName,CreationTimeUtc,ServiceCounterValue) values (
        @ServiceCounterId,@SnapshotMachineName,@CreationTimeUtc,@ServiceCounterValue)", snapshot);
                }

            }
        }

        private String GetPerfCounterPath(PerformanceCounter cnt)
        {
            return String.Format(@"{0}\{1}\{2}\{3}", cnt.MachineName, cnt.CategoryName, cnt.CounterName, cnt.InstanceName);
        }
    }
}
