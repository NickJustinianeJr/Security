create table services(
  Name varchar(100) primary key,
  DisplayName varchar(1000) null
) engine = InnoDB;

create table service_counters(
  Id int auto_increment primary key,
  ServiceName varchar(100) not null references services(Name),
  MachineName varchar(100) null,
  CategoryName varchar(100) not null,
  CounterName varchar(100) not null,
  InstanceName varchar(100) null,
  DisplayName varchar(1000) null,
  DisplayType enum('table', 'graph') null
) engine = InnoDB;

create table service_counter_snapshots(
  Id int auto_increment,
  ServiceCounterId int not null,
  SnapshotMachineName varchar(100) null,
  CreationTimeUtc datetime not null,
  ServiceCounterValue float null,
  primary key (Id, CreationTimeUtc)
) engine = InnoDB
partition by range columns(CreationTimeUtc)
(partition p20121018 values less than ('2012-10-19 00:00'),
 partition p20121019 values less than ('2012-10-20 00:00'));
